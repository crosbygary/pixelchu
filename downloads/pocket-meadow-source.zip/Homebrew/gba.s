.syntax unified
.cpu arm7tdmi
.arm
.text
.global _start
_start:
 b entry
 .space 188
entry:
 mov r0,#0x4000000
 ldr r1,=0x403
 strh r1,[r0]
 mov r8,#112
 mov r9,#72
 ldr r10,=0x2546
 ldr r11,=0x06000000
 // Fill a meadow; no copyrighted graphics or data.
 mov r1,r11
 ldr r2,=38400
fill:
 strh r10,[r1],#2
 subs r2,r2,#1
 bne fill
loop:
 ldrh r1,[r0,#6]
 cmp r1,#160
 bge loop
blank:
 ldrh r1,[r0,#6]
 cmp r1,#160
 blt blank
 // Erase the previous square.
 mov r6,r10
 .word 0xeb000000 | (((square - . - 8) / 4) & 0xffffff)
 ldr r1,=0x04000130
 ldrh r1,[r1]
 tst r1,#16
 addeq r8,r8,#1
 tst r1,#32
 subeq r8,r8,#1
 tst r1,#64
 subeq r9,r9,#1
 tst r1,#128
 addeq r9,r9,#1
 tst r1,#8
 moveq r8,#112
 moveq r9,#72
 cmp r8,#0
 movlt r8,#0
 cmp r8,#231
 movgt r8,#231
 cmp r9,#0
 movlt r9,#0
 cmp r9,#151
 movgt r9,#151
 ldr r6,=0x1b7f
 tst r1,#1
 ldreq r6,=0x7c7f
 tst r1,#2
 ldreq r6,=0x7fe0
 .word 0xeb000000 | (((square - . - 8) / 4) & 0xffffff)
 b loop
square:
 mov r2,#240
 mul r3,r9,r2
 add r3,r3,r8
 add r3,r11,r3,lsl #1
 mov r4,#8
row:
 mov r5,#8
pixel:
 strh r6,[r3],#2
 subs r5,r5,#1
 bne pixel
 add r3,r3,#464
 subs r4,r4,#1
 bne row
 bx lr
.ltorg
